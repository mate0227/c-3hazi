using System;

namespace Example
{
    public static class StringExtensions
    {
        public static string ReverseStr(this string str)
        {
            var chars = str.ToCharArray();
            Array.Reverse(chars);
            return new string(chars);
        }

        public static int ToInt(this string str)
        {
            return int.Parse(str);
        }

        public static string Capitalize(this string str)
        {
             return char.ToUpper(str[0]) + str.Substring(1);
        }

        public static char StartingLetter(this string str)
        {
            char c = str[0];
            return c;
        }
    }
}
