﻿using System;
using static System.Console;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

namespace Example
{
    public class Program
    {
        public static void Main(string[] args)
        {
            //feladat_1();
            //feladat_2();
            //feladat_3();
            //feladat_4();
            //feladat_5();
            //feladat_6();
            //feladat_7();
            //feladat_8();
            //feladat_9();
            //feladat_10();
            //feladat_11();
            //feladat_12();
            //feladat_13();
            //feladat_14();
            //feladat_15();
            //ezer();

            //string s = "42";
            //WriteLine(s.ToInt());


            //int n = 1127317235;
            //WriteLine(n.ToString().ReverseStr());
            
           
        }   

        private static void feladat_1()
        {
      
            var input = new List<string>{"auto","villamos","metro"};
            var result = input.Select(s => s.ToUpper() + "!").ToList();

            WriteLine(string.Join(", ",result));
        }
        
        private static void feladat_2()
        {
            var input = new List<string>{"aladar", "bela", "cecil"};
            var result = input.Select(s=>s.Capitalize()).ToList();

            WriteLine(string.Join(",",result));
        }
                private static void feladat_3()
        {
            // var lista = PyUtils.Range(10);
            // var result = lista.Select(x => 0).ToList();

            var result = Enumerable.Repeat(0, 10).ToList();

            // WriteLine(string.Join(", ", lista));
            WriteLine(string.Join(", ", result));
        }
              private static void feladat_4()
        {
            // var input = PyUtils.Range(1, 10+1);
            var input = Enumerable.Range(1, 10);

            WriteLine(string.Join(", ", input));
            // WriteLine(string.Join(", ", result));
        }

        private static void feladat_5()
        {
            var input = new List<string>{"1","2","3","4","5","6","7","8","9","10"};
            var result = input.Select(s=>s.ToInt()).ToList();

            WriteLine(string.Join(", ",result)); 
        }
        private static void feladat_6()
        {
            var text = "1234567";
            var result = text.Select(c => c - '0').ToList();

            WriteLine(string.Join(", ", result));
        }
        private static void feladat_7()
        {
            var text = "The quick brown fox jumps over the lazy dog";
            var words = text.Split(" ");
            var result = words.Select(s=>s.Length).ToList();

            WriteLine(string.Join(", ",result));
        }

        private static void feladat_8()
        {
            var input = "python is an awesome language";
            var words = input.Split(" ");
            var result = words.Select(s=>s.StartingLetter()).ToList();

            WriteLine(string.Join(", ",result));
        }

        private static void feladat_9()
        {
            var input = "The quick brown fox jumps over the lazy dog";
            var words = input.Split(" ");
            var result = words.Select(s=>"'"+s+"'"+" , "+s.Length).ToList();

            WriteLine(string.Join(", ",result));
        }
        private static void feladat_10()
        {
            var nums = new List<int>();
            for(int i = 0;i<10;i++)
            {
                
                if(i%2==0)
                {
                    nums.Add(i);

                }
            }
            WriteLine(string.Join(", ",nums));
        }

        private static void feladat_11()
        {
            var nums = new List<int>();

            for(int i = 0;i<20;i++)
            {
                nums.Add(i*i);
            }
            
            var result = nums.Where(i=> i%2==0).ToList();
            WriteLine(string.Join(", ",result));

        }

        private static void feladat_12()
        {
            var nums = new List<string>();
        
            for(int i = 0;i<20;i++)
            {
                nums.Add(i*i+"");
                //WriteLine(nums[i]);
            }

            var result = nums.Where(x=>x.EndsWith("4")).ToList();

            WriteLine(string.Join(", ",result));

        }

        private static void feladat_13()
        {

            var letters = new List<char>();

            for(int i = 65;i<=90;i++)
            {
                letters.Add(Convert.ToChar(i));

            }
            string result = "";
            for(int i= 0;i<letters.Count;i++)
            {
                result+=letters[i];
            }
            WriteLine(result);

        }


        private static void feladat_14()
        {
            var input = new List<string>{" apple ", " banana ", " kiwi"};

            var result = input.Select(x=>x.Trim()).ToList();

            WriteLine(string.Join(",",result));

        }

        private static void feladat_15()
        {
            var input = new List<string>{"1", "0", "1", "1", "0", "1", "0", "0"};

            string result = "";

            for(int i = 0;i<input.Count;i++)
            {
                result+=input[i];

            }

            WriteLine(result);
        }

        private static void ezer()
        {
            var szamok = new List<int>();
            for(int i = 0;i<1000;i++)
            {
                szamok.Add(i);
            }
            WriteLine(szamok.Where(x=>x%3==0||x%5==0).Sum());
            
        }

  


    }
}
